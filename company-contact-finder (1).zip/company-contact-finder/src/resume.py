"""
resume.py - Checkpoint / resume-after-crash support
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Set

import config

log = logging.getLogger("crawler")


def load_completed() -> Set[str]:
    """Return set of company names already processed."""
    path = config.CHECKPOINT_FILE
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        completed: Set[str] = set(data.get("completed", []))
        log.info("Checkpoint loaded – %d companies already done", len(completed))
        return completed
    except Exception as exc:
        log.warning("Could not read checkpoint (%s); starting fresh", exc)
        return set()


def save_checkpoint(completed: Set[str]) -> None:
    """Persist the set of completed company names."""
    path = config.CHECKPOINT_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.write_text(
            json.dumps({"completed": sorted(completed)}, indent=2),
            encoding="utf-8",
        )
    except Exception as exc:
        log.error("Failed to save checkpoint: %s", exc)


def mark_done(company: str, completed: Set[str]) -> None:
    """Add a company to the completed set and persist immediately."""
    completed.add(company)
    save_checkpoint(completed)


def reset_checkpoint() -> None:
    """Delete checkpoint (useful for a fresh run)."""
    path = config.CHECKPOINT_FILE
    if path.exists():
        path.unlink()
        log.info("Checkpoint reset.")
