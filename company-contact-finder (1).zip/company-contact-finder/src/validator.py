"""
validator.py - Post-extraction filtering and ranking
"""

from __future__ import annotations

import re
from typing import List, Optional

import phonenumbers

# Emails that are almost certainly not a company contact
_GENERIC_PREFIXES = re.compile(
    r"^(noreply|no-reply|donotreply|support@example|"
    r"webmaster|postmaster|bounce|mailer-daemon|abuse|"
    r"privacy@|legal@|dpo@|gdpr@|feedback@)",
    re.I,
)

# Preferred prefixes (contact / info are most likely to be correct)
_PREFERRED_PREFIXES = re.compile(
    r"^(contact|info|hello|hi|enquir|inquir|sales|"
    r"office|admin|mail|get|reach)",
    re.I,
)


def _email_score(email: str) -> int:
    """Higher = more likely to be the main contact email."""
    local = email.split("@")[0]
    if _PREFERRED_PREFIXES.match(local):
        return 10
    if _GENERIC_PREFIXES.match(email):
        return -5
    return 5


def best_email(emails: List[str]) -> Optional[str]:
    """Pick the single best email from a list."""
    if not emails:
        return None
    ranked = sorted(emails, key=_email_score, reverse=True)
    return ranked[0]


def best_phone(phones: List[str]) -> Optional[str]:
    """Pick the single best phone number (prefer toll-free / shorter)."""
    if not phones:
        return None
    # Prefer numbers that look like main office lines (not mobile-only)
    for p in phones:
        try:
            num = phonenumbers.parse(p)
            nt = phonenumbers.number_type(num)
            if nt in (phonenumbers.PhoneNumberType.FIXED_LINE,
                      phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE,
                      phonenumbers.PhoneNumberType.TOLL_FREE):
                return p
        except Exception:
            pass
    return phones[0]


def validate_url(url: Optional[str]) -> Optional[str]:
    """Return url if it looks valid, else None."""
    if not url:
        return None
    if not url.startswith(("http://", "https://")):
        return None
    if len(url) > 512:
        return None
    return url
