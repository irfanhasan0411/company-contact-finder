"""
crawler.py - Async HTTP fetcher with rate limiting and retry logic
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from typing import Optional, Tuple

import aiohttp
from fake_useragent import UserAgent
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

import config
from src.utils import normalise_url, get_base_url

log = logging.getLogger("crawler")

_ua = UserAgent()

# Per-domain rate limiter: track last request time
_domain_last_hit: dict[str, float] = defaultdict(float)
_domain_lock:    dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)


async def _rate_limit(domain: str) -> None:
    """Enforce a minimum delay between successive requests to the same domain."""
    async with _domain_lock[domain]:
        elapsed = time.monotonic() - _domain_last_hit[domain]
        wait = config.RATE_LIMIT_DELAY - elapsed
        if wait > 0:
            await asyncio.sleep(wait)
        _domain_last_hit[domain] = time.monotonic()


def _make_headers() -> dict:
    return {
        **config.DEFAULT_HEADERS,
        "User-Agent": _ua.random,
    }


@retry(
    stop=stop_after_attempt(config.RETRY_ATTEMPTS),
    wait=wait_exponential(multiplier=1, min=2, max=8),
    retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
    reraise=True,
)
async def fetch(
    session: aiohttp.ClientSession,
    url: str,
    *,
    follow_redirects: bool = True,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Fetch *url* and return ``(final_url, html_text)``.
    Returns ``(None, None)`` on unrecoverable error.
    """
    url = normalise_url(url)
    domain = get_base_url(url)
    await _rate_limit(domain)

    timeout = aiohttp.ClientTimeout(total=config.REQUEST_TIMEOUT)
    try:
        async with session.get(
            url,
            headers=_make_headers(),
            timeout=timeout,
            allow_redirects=follow_redirects,
            ssl=False,               # many corporate sites have misconfigured certs
        ) as resp:
            if resp.status >= 400:
                log.debug("HTTP %d for %s", resp.status, url)
                return None, None
            # Only parse text/html responses
            ct = resp.content_type or ""
            if "html" not in ct and "text" not in ct:
                return str(resp.url), None
            html = await resp.text(errors="replace")
            return str(resp.url), html
    except Exception as exc:
        log.debug("Fetch error %s → %s", url, exc)
        raise  # let tenacity retry


async def safe_fetch(
    session: aiohttp.ClientSession,
    url: str,
) -> Tuple[Optional[str], Optional[str]]:
    """Like ``fetch`` but swallows all exceptions and returns ``(None, None)``."""
    try:
        return await fetch(session, url)
    except Exception as exc:
        log.debug("safe_fetch gave up on %s: %s", url, exc)
        return None, None


def make_session(connector: Optional[aiohttp.TCPConnector] = None) -> aiohttp.ClientSession:
    """Create a shared aiohttp session."""
    conn = connector or aiohttp.TCPConnector(
        limit=config.MAX_WORKERS * 2,
        ssl=False,
        enable_cleanup_closed=True,
    )
    return aiohttp.ClientSession(connector=conn)
