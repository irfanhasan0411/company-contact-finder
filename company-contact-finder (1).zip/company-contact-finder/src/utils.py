"""
utils.py - Shared helpers
"""

import re
import asyncio
import random
from urllib.parse import urlparse, urljoin
from typing import Optional


# ── URL helpers ────────────────────────────────────────────────────────────────

def normalise_url(url: str) -> str:
    """Ensure a URL has a scheme and strip trailing slashes."""
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url.rstrip("/")


def get_base_url(url: str) -> str:
    """Return scheme + netloc (e.g. https://example.com)."""
    p = urlparse(normalise_url(url))
    return f"{p.scheme}://{p.netloc}"


def is_same_domain(url: str, base: str) -> bool:
    """True if *url* belongs to the same registered domain as *base*."""
    host_a = urlparse(normalise_url(url)).netloc.lstrip("www.")
    host_b = urlparse(normalise_url(base)).netloc.lstrip("www.")
    return host_a == host_b


def make_absolute(href: str, base: str) -> str:
    """Turn a possibly-relative href into an absolute URL."""
    return urljoin(base, href)


# ── Text helpers ───────────────────────────────────────────────────────────────

_GARBAGE_DOMAINS = re.compile(
    r"\.(png|jpg|jpeg|gif|svg|css|js|ico|woff|woff2|ttf|pdf|zip)$",
    re.I,
)

def looks_like_contact_link(href: str, text: str) -> bool:
    """Heuristic: does this anchor look like a contact/about page?"""
    combined = (href + " " + text).lower()
    keywords = ("contact", "about", "support", "imprint", "impressum",
                 "legal", "privacy", "team", "office", "reach", "touch")
    return any(k in combined for k in keywords)


def clean_email(email: str) -> str:
    return email.strip().lower()


def clean_phone(phone: str) -> str:
    return phone.strip()


# ── Async helpers ──────────────────────────────────────────────────────────────

async def random_delay(lo: float = 0.5, hi: float = 2.0) -> None:
    await asyncio.sleep(random.uniform(lo, hi))


# ── Misc ───────────────────────────────────────────────────────────────────────

def truncate(s: str, n: int = 80) -> str:
    return s if len(s) <= n else s[:n - 1] + "…"
