"""
search.py - Website discovery via Brave Search API or DuckDuckGo fallback
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Optional
from urllib.parse import urlparse

import aiohttp
from tenacity import retry, stop_after_attempt, wait_exponential

import config
from src.utils import normalise_url

log = logging.getLogger("crawler")

# Patterns that strongly suggest a search-engine result page, not the company
_JUNK_HOSTS = re.compile(
    r"(linkedin\.com|facebook\.com|twitter\.com|instagram\.com|"
    r"youtube\.com|wikipedia\.org|glassdoor\.com|indeed\.com|"
    r"zoominfo\.com|crunchbase\.com|bloomberg\.com|reuters\.com|"
    r"amazon\.com|flipkart\.com|justdial\.com|indiamart\.com)",
    re.I,
)


def _is_likely_official(url: str, company: str) -> bool:
    """
    Rough heuristic: the result URL should look like a company homepage
    and not be a well-known directory site.
    """
    if not url:
        return False
    parsed = urlparse(url)
    host = parsed.netloc.lower()
    if _JUNK_HOSTS.search(host):
        return False
    # Prefer short paths (homepages)
    if len(parsed.path.strip("/").split("/")) > 3:
        return False
    return True


# ── Brave Search ───────────────────────────────────────────────────────────────

async def _brave_search(session: aiohttp.ClientSession, company: str) -> Optional[str]:
    """Query the Brave Search API and return the best URL."""
    url = "https://api.search.brave.com/res/v1/web/search"
    params = {"q": f"{company} official website", "count": 5}
    headers = {
        "Accept":              "application/json",
        "Accept-Encoding":     "gzip",
        "X-Subscription-Token": config.BRAVE_API_KEY,
    }
    try:
        async with session.get(url, params=params, headers=headers,
                               timeout=aiohttp.ClientTimeout(total=10)) as resp:
            if resp.status != 200:
                log.debug("Brave returned HTTP %d for %r", resp.status, company)
                return None
            data = await resp.json()
            results = data.get("web", {}).get("results", [])
            for r in results:
                candidate = r.get("url", "")
                if _is_likely_official(candidate, company):
                    return normalise_url(candidate)
    except Exception as exc:
        log.debug("Brave search error for %r: %s", company, exc)
    return None


# ── DuckDuckGo fallback ────────────────────────────────────────────────────────

async def _ddg_search(company: str) -> Optional[str]:
    """
    Use the duckduckgo-search library (sync) in a thread pool to avoid
    blocking the event loop.
    """
    def _sync() -> Optional[str]:
        try:
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                for r in ddgs.text(f"{company} official website", max_results=5):
                    href = r.get("href", "")
                    if _is_likely_official(href, company):
                        return normalise_url(href)
        except Exception as exc:
            log.debug("DDG search error for %r: %s", company, exc)
        return None

    return await asyncio.get_event_loop().run_in_executor(None, _sync)


# ── Public API ─────────────────────────────────────────────────────────────────

@retry(stop=stop_after_attempt(config.RETRY_ATTEMPTS),
       wait=wait_exponential(multiplier=1, min=2, max=10),
       reraise=False)
async def find_website(session: aiohttp.ClientSession, company: str) -> Optional[str]:
    """
    Return the best-guess official website URL for *company*.
    Tries Brave first (if API key present), then DuckDuckGo.
    """
    if config.BRAVE_API_KEY:
        url = await _brave_search(session, company)
        if url:
            log.debug("Brave → %s for %r", url, company)
            return url

    url = await _ddg_search(company)
    if url:
        log.debug("DDG → %s for %r", url, company)
    return url
