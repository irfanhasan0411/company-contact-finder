"""
extractor.py - Email and phone extraction from HTML pages
"""

from __future__ import annotations

import json
import logging
import re
from typing import List, Optional, Set

import phonenumbers
from bs4 import BeautifulSoup

import config

log = logging.getLogger("crawler")

# ── Email patterns ─────────────────────────────────────────────────────────────

# Broad regex: catches obfuscated emails like user [at] domain [dot] com
_EMAIL_RE = re.compile(
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
    re.I,
)

# Obfuscated patterns (e.g. " at ", " [at] ", " (at) ")
_OBF_RE = re.compile(
    r"([a-zA-Z0-9._%+\-]+)\s*[\[\(]?\s*at\s*[\]\)]?\s*"
    r"([a-zA-Z0-9.\-]+)\s*[\[\(]?\s*dot\s*[\]\)]?\s*"
    r"([a-zA-Z]{2,})",
    re.I,
)

# Domains that indicate a false positive (images, scripts, w3c namespaces …)
_JUNK_EMAIL_DOMAINS = re.compile(
    r"\.(png|jpg|jpeg|gif|svg|css|js|ico|woff|example|w3|sentry|"
    r"yourdomain|domain|email|company|mail\.com)$",
    re.I,
)


def _deobfuscate(text: str) -> List[str]:
    """Convert 'user [at] domain [dot] com' style emails."""
    emails: List[str] = []
    for m in _OBF_RE.finditer(text):
        emails.append(f"{m.group(1)}@{m.group(2)}.{m.group(3)}")
    return emails


def _filter_emails(candidates: List[str]) -> List[str]:
    seen: Set[str] = set()
    result: List[str] = []
    for e in candidates:
        e = e.lower().strip()
        if _JUNK_EMAIL_DOMAINS.search(e):
            continue
        if e in seen:
            continue
        seen.add(e)
        result.append(e)
    return result


def extract_emails(html: str, final_url: str = "") -> List[str]:
    """Return all unique, valid-looking email addresses found in *html*."""
    emails: List[str] = []

    soup = BeautifulSoup(html, "lxml")

    # 1. mailto: links
    for a in soup.find_all("a", href=True):
        href: str = a["href"]
        if href.startswith("mailto:"):
            addr = href[7:].split("?")[0].strip()
            emails.append(addr)

    # 2. JSON-LD blocks
    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string or "")
            text = json.dumps(data)
            emails.extend(_EMAIL_RE.findall(text))
        except Exception:
            pass

    # 3. Meta tags
    for meta in soup.find_all("meta"):
        content = meta.get("content", "")
        emails.extend(_EMAIL_RE.findall(content))

    # 4. Footer / header text
    for tag in soup.find_all(["footer", "header"]):
        text = tag.get_text(" ", strip=True)
        emails.extend(_EMAIL_RE.findall(text))
        emails.extend(_deobfuscate(text))

    # 5. Script tag content
    for script in soup.find_all("script"):
        src = script.string or ""
        emails.extend(_EMAIL_RE.findall(src))

    # 6. Full page text (catches everything else)
    full_text = soup.get_text(" ", strip=True)
    emails.extend(_EMAIL_RE.findall(full_text))
    emails.extend(_deobfuscate(full_text))

    return _filter_emails(emails)


# ── Phone patterns ─────────────────────────────────────────────────────────────

def extract_phones(html: str, regions: Optional[List[str]] = None) -> List[str]:
    """
    Return all unique, valid phone numbers found in *html*.
    Uses the `phonenumbers` library for reliable parsing.
    """
    if regions is None:
        regions = config.PHONE_REGIONS

    soup = BeautifulSoup(html, "lxml")
    text = soup.get_text(" ", strip=True)

    found: Set[str] = set()

    for region in regions:
        try:
            for match in phonenumbers.PhoneNumberMatcher(text, region):
                num = match.number
                if phonenumbers.is_valid_number(num):
                    formatted = phonenumbers.format_number(
                        num, phonenumbers.PhoneNumberFormat.INTERNATIONAL
                    )
                    found.add(formatted)
        except Exception:
            pass

    return sorted(found)


# ── Combined entry point ───────────────────────────────────────────────────────

def extract_contacts(html: str, url: str = "") -> dict:
    """Return {'emails': [...], 'phones': [...]}."""
    return {
        "emails": extract_emails(html, url),
        "phones": extract_phones(html),
    }
