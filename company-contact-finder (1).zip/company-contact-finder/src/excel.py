"""
excel.py - Read input Excel and write output Excel
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Dict, Any

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

import config

log = logging.getLogger("crawler")

# Convenience type alias
Row = Dict[str, Any]


# ── Read ───────────────────────────────────────────────────────────────────────

def read_companies(path: Path = config.INPUT_FILE) -> List[Row]:
    """
    Read the input workbook and return a list of dicts.

    Required column  : "Company Name"
    Optional columns : "Website", "Email", "Phone", "Status"

    Extra columns are preserved as-is.
    """
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")

    wb = openpyxl.load_workbook(path)
    ws = wb.active

    headers = [cell.value for cell in ws[1]]
    rows: List[Row] = []

    for excel_row in ws.iter_rows(min_row=2, values_only=True):
        row: Row = dict(zip(headers, excel_row))
        # Normalise mandatory column
        if not row.get(config.COL_COMPANY):
            continue
        row[config.COL_COMPANY] = str(row[config.COL_COMPANY]).strip()
        # Ensure result columns exist
        for col in (config.COL_WEBSITE, config.COL_EMAIL,
                    config.COL_PHONE, config.COL_STATUS):
            row.setdefault(col, "")
            if row[col] is None:
                row[col] = ""
        rows.append(row)

    log.info("Read %d companies from %s", len(rows), path)
    return rows


# ── Write ──────────────────────────────────────────────────────────────────────

_HEADER_FILL  = PatternFill("solid", fgColor="1F4E79")
_HEADER_FONT  = Font(bold=True, color="FFFFFF", size=11)
_DONE_FILL    = PatternFill("solid", fgColor="E2EFDA")   # light green
_PARTIAL_FILL = PatternFill("solid", fgColor="FFF2CC")   # light yellow
_FAIL_FILL    = PatternFill("solid", fgColor="FCE4D6")   # light red


def write_companies(rows: List[Row], path: Path = config.OUTPUT_FILE) -> None:
    """Write rows to the output workbook with conditional formatting."""
    path.parent.mkdir(parents=True, exist_ok=True)

    if not rows:
        log.warning("No rows to write.")
        return

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Companies"

    # Determine column order: mandatory first, then any extras
    priority = [config.COL_COMPANY, config.COL_WEBSITE,
                config.COL_EMAIL,   config.COL_PHONE, config.COL_STATUS]
    extra = [k for k in rows[0].keys() if k not in priority]
    all_cols = priority + extra

    # Header row
    for col_idx, col_name in enumerate(all_cols, start=1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(horizontal="center")

    # Data rows
    for row_idx, row in enumerate(rows, start=2):
        for col_idx, col_name in enumerate(all_cols, start=1):
            ws.cell(row=row_idx, column=col_idx, value=row.get(col_name, ""))

        # Row-level colour based on how much we found
        found = sum([
            bool(row.get(config.COL_WEBSITE)),
            bool(row.get(config.COL_EMAIL)),
            bool(row.get(config.COL_PHONE)),
        ])
        fill = _DONE_FILL if found == 3 else (_PARTIAL_FILL if found >= 1 else _FAIL_FILL)
        for col_idx in range(1, len(all_cols) + 1):
            ws.cell(row=row_idx, column=col_idx).fill = fill

    # Auto-fit column widths (capped at 60)
    for col_idx, col_name in enumerate(all_cols, start=1):
        max_len = max(
            len(str(col_name)),
            *(len(str(row.get(col_name, "") or "")) for row in rows),
        )
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 4, 60)

    # Freeze header
    ws.freeze_panes = "A2"

    wb.save(path)
    log.info("Saved %d rows → %s", len(rows), path)


def create_sample_input(path: Path = config.INPUT_FILE) -> None:
    """Create a sample input workbook if none exists."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Companies"
    ws.append([config.COL_COMPANY, config.COL_WEBSITE,
               config.COL_EMAIL,   config.COL_PHONE])
    sample = [
        ("Infosys", "", "", ""),
        ("Wipro", "", "", ""),
        ("Tata Consultancy Services", "", "", ""),
        ("HCL Technologies", "", "", ""),
        ("Tech Mahindra", "", "", ""),
    ]
    for row in sample:
        ws.append(row)
    wb.save(path)
    log.info("Created sample input at %s", path)
