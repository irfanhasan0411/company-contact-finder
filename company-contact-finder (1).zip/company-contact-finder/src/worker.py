"""
worker.py - Per-company async processing pipeline
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional, Tuple, List
from urllib.parse import urljoin

import aiohttp

import config
from src.crawler import safe_fetch
from src.extractor import extract_contacts
from src.search import find_website
from src.utils import get_base_url, normalise_url, looks_like_contact_link
from src.validator import best_email, best_phone, validate_url

log = logging.getLogger("crawler")


async def _find_contact_pages(
    session: aiohttp.ClientSession,
    base_url: str,
    homepage_html: str,
) -> List[str]:
    """
    Return a list of candidate contact/about page URLs.
    Strategy:
      1. Well-known path probes (config.CONTACT_PATHS)
      2. Anchor-tag scan of the homepage
    """
    candidates: List[str] = []
    seen = {base_url}

    # 1. Probe well-known paths
    probe_tasks = []
    for path in config.CONTACT_PATHS:
        url = base_url.rstrip("/") + path
        if url not in seen:
            seen.add(url)
            probe_tasks.append(_check_url_exists(session, url))

    results = await asyncio.gather(*probe_tasks, return_exceptions=True)
    for url, ok in zip(
        [base_url.rstrip("/") + p for p in config.CONTACT_PATHS], results
    ):
        if ok is True:
            candidates.append(url)

    # 2. Anchor-tag scan of homepage
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(homepage_html, "lxml")
    for a in soup.find_all("a", href=True):
        href: str = a["href"].strip()
        text: str = a.get_text(strip=True)
        if not href or href.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue
        abs_url = urljoin(base_url, href)
        if abs_url not in seen and looks_like_contact_link(href, text):
            seen.add(abs_url)
            candidates.append(abs_url)

    return candidates[:10]  # cap to avoid runaway crawling


async def _check_url_exists(
    session: aiohttp.ClientSession, url: str
) -> bool:
    """HEAD request to check if a URL returns 2xx/3xx."""
    try:
        timeout = aiohttp.ClientTimeout(total=8)
        async with session.head(url, timeout=timeout, ssl=False,
                                allow_redirects=True) as resp:
            return resp.status < 400
    except Exception:
        return False


async def process_company(
    session: aiohttp.ClientSession,
    company: str,
    existing_website: str = "",
    existing_email: str = "",
    existing_phone: str = "",
) -> Tuple[Optional[str], Optional[str], Optional[str], str]:
    """
    Full pipeline for a single company.

    Returns (website, email, phone, status_message).
    """
    log.info("Processing: %s", company)

    # ── Step 1: resolve website ─────────────────────────────────────────────
    website = validate_url(existing_website) if existing_website else None
    if not website:
        website = await find_website(session, company)

    if not website:
        log.warning("No website found for %r", company)
        return None, None, None, "No website found"

    website = normalise_url(website)
    base_url = get_base_url(website)

    # ── Step 2: fetch homepage ──────────────────────────────────────────────
    final_url, homepage_html = await safe_fetch(session, website)
    if not homepage_html:
        log.warning("Could not fetch homepage for %r (%s)", company, website)
        return website, None, None, "Homepage fetch failed"

    # Collect contacts from homepage first
    all_emails: list[str] = []
    all_phones: list[str] = []

    contacts = extract_contacts(homepage_html, final_url or website)
    all_emails.extend(contacts["emails"])
    all_phones.extend(contacts["phones"])

    # ── Step 3: find & crawl contact pages ─────────────────────────────────
    contact_pages = await _find_contact_pages(session, base_url, homepage_html)
    log.debug("%s → probing %d contact pages", company, len(contact_pages))

    page_tasks = [safe_fetch(session, url) for url in contact_pages]
    page_results = await asyncio.gather(*page_tasks, return_exceptions=True)

    for result in page_results:
        if isinstance(result, Exception) or result is None:
            continue
        page_url, page_html = result
        if not page_html:
            continue
        c = extract_contacts(page_html, page_url or "")
        all_emails.extend(c["emails"])
        all_phones.extend(c["phones"])

    # ── Step 4: pick best candidates ────────────────────────────────────────
    email = best_email(all_emails) if not existing_email else existing_email
    phone = best_phone(all_phones) if not existing_phone else existing_phone

    parts = []
    if website:
        parts.append("Website ✓")
    if email:
        parts.append("Email ✓")
    if phone:
        parts.append("Phone ✓")
    status = " | ".join(parts) if parts else "No contacts found"

    log.info("Done: %s → %s", company, status)
    return website, email, phone, status
